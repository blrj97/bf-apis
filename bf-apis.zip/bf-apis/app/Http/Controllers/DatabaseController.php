<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Models\Client;
use App\Models\Database;
use DB;

class DatabaseController extends Controller
{
    public function register(Request $request)
    {
        $validator=Validator::make(
        $request->all(),[
        'name' => 'required|max:255',
        'password' => 'required',
        'email' => 'required|unique:users',
            ]);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }
        else{
            Database::insert([
            'name' => $request->name,
            'email'=>$request->email,
            'password'=>hash::make($request->password),   
                ]);
            return response()->json([
                "$request->email" => "Created Succefully",
                'alert' => 'Success',
            ]);
        }
    }

    public function update(Request $request)
    {
        if($request->isMethod('post')) {
            $validator=Validator::make(
            $request->all(),[
            'name' => 'required|max:255',
            'password' => 'required',
            ]);
            if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
            }
            else {
            $user=Database::where('id',$request->user_id)->update([
            'name' => $request->name,
            'password' => Hash::make($request->password),
                ]);
            return response()->json([
                'message' => "User Updated successfully.",
                'alert-type' => 'success']);
            }
        }
        $user=Database::select('id','name','email')->where('id',$request->user_id)->first();
            return response()->json(['user'=>$user]);
    }

    public function connection(Request $request)
    {
        $details = Database::select('id','name','email')->get();  
        return response()->json( $details);
    }
}
