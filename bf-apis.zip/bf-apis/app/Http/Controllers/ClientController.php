<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Models\Client;
use Illuminate\Http\Request;
use DB;

class ClientController extends Controller
{
    public function add(Request $request)
    {
        $validator =Validator::make(
        $request->all(),['name'=>'required',
        'org'=>'required',
        'email'=>'required|unique:clients',
        'password'=>'required',
        'contact_no'=>'required|numeric',
        'address'=>'required',
        'pincode'=>'required',
        'state'=>'required',
        'country'=>'required',
        'db_name'=>'required',
        'db_username'=>'required',
        'db_password'=>'required',
        'status',
        'port'=>'required',
        'host'=>'required|unique:clients'
        ]);
    if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }
    else{
        $client=new Client;
        $client->name=$request->name;
        $client->org=$request->org;
        $client->email=$request->email;
        $client->password=hash::make($request->password);
        $client->contact_no=$request->contact_no;
        $client->address=$request->address;
        $client->pincode=$request->pincode;
        $client->state=$request->state;
        $client->country=$request->country;
        $client->db_name=$request->db_name;
        $client->db_username=$request->db_username;
        $client->db_password=$request->db_password;
        $client->host=$request->host;
        $client->port=$request->port;
        $client->save();   
        return response()->json([
        "Message" => "Client Saved Succefully",
                    'alert' => 'Success',
            ]); 
        }
    }

    public function get(Request $request)
    {
        $client=Client::all('id','name','org','email','contact_no','address','pincode',
        'state','country','db_name','db_username','db_password','host','port','status');
        return response()->json( $client);
    }

    public function update(Request $request)
    {
        if($request->isMethod('post')){
            $validator = Validator::make(
            $request->all(),[
            'name' => 'required',
            'org' => 'required',
            'password' => 'required',
            'contact_no' => 'required|numeric',
            'address' => 'required',
            'pincode' => 'required',
            'state' => 'required',
            'country' => 'required',
            'status' =>'required',
                ]);
        if ($validator->fails()) {
                return response()->json($validator->errors(), 400);
            }
        else{
            $client=Client::find($request->id);
            $client->name=$request->name;
            $client->org=$request->org;
            $client->password=hash::make($request->password);
            $client->contact_no=$request->contact_no;
            $client->address=$request->address;
            $client->pincode=$request->pincode;
            $client->state=$request->state;
            $client->country=$request->country;
            $client->status=$request->status;
            $client->save();   
            return response()->json([
            "Message" => "Database Updated Succefully",
                        'alert' => 'Success',
                        ]); 
            }
        }
        $client = Client::select('name','org','contact_no','address',
                'pincode','state','country','status')->find($request->id);
            return response()->json($client);     
    }

    public function status(Request $request)
    {
        $validator = Validator::make($request->only('status'),[
            'status'=> 'required',
            ]);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }
        else{
            $client=Client::find($request->id);
            $client->status=$request->status;
            $client->save();   
            return response()->json([
            "Message" => "Database Status Updated Succefully",
            "alert" => "Success",
            ]);
        }
    }
}