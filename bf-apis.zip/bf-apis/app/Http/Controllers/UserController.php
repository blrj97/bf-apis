<?php
namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Password;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;    
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Exception;
use Auth;
use DB;

class UserController extends Controller
{
    public function login(Request $request)
    {
        $validator = Validator::make($request->only('email', 'password'), 
        ['email' => 'required|email',
        'password' => 'required']);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 401);
            }
        else{
            $credentials = $request->only('email', 'password');
        if ($token = JWTAuth::attempt($credentials)) {
            return $this->respondWithToken($token);
            }
        try {
        if (! $token = JWTAuth::attempt($credentials)) {
            return response()->json(['error' => 'invalid_credentials'], 401);
                }
            } 
        catch (JWTException $e) {
            return response()->json(['error' => 'could_not_create_token'], 500);
            }
        }
    }

    public function register(Request $request)
    {
        $validator = Validator::make(
        $request->all(), 
        [
            'name' => 'required|string|max:255',
            'org' => 'required',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
            'contact_no' => 'required|numeric',
            'role' => 'required|unique:users',
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
            }
        else{
            $user = User::create([
            'name' => $request->get('name'),
            'org' => $request->get('org'),
            'email' => $request->get('email'),
            'password' => Hash::make($request->get('password')),
            'contact_no' => $request->get('contact_no'),
            'role' => $request->get('role'),
            ]);
            $token = JWTAuth::fromUser($user);
            return response()->json(compact('user','token'),201);
        } 
    }

    public function profile()
    {
        try {
            if (! $user = JWTAuth::parseToken()->authenticate()) {
                return response()->json(['user_not_found'], 404);
            }
        } 
        catch (TokenExpiredException $e) {
            return response()->json(['token_expired'], $e->getStatusCode());
        } 
        catch (TokenInvalidException $e) {
            return response()->json(['token_invalid'], $e->getStatusCode());
        } 
        catch (JWTException $e) {
            return response()->json(['token_absent'], $e->getStatusCode());
        }
            return response()->json(compact('user'));
    }

    public function logout(Request $request)
    {   
        JWTAuth::invalidate($request->token);
        return response()->json([
            'success' => true,
            'message' => 'User has been logged out'
        ]);
    }

    public function refresh()
    {
        return $this->respondWithToken($this->guard()->refresh());
    }

    protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => $this->guard()->factory()->getTTL() * 60,
            'user' => auth()->user()
        ]);
    }

    public function guard()
    {
        return Auth::guard();
    }

    public function validatePasswordRequest(Request $request)
    {
        $user = DB::table('users')->where('email', '=', $request->email)
            ->first();
        //Check if the user exists            
        if (!$user) {
            return response()->json([
                "$request->email" => "User Does Not Exist",
                'alert' => 'error',
            ]);
        }
        //Create Password Reset Token
        DB::table('password_resets')->insert([
            'user_id'=>$user->id,
            'email' => $request->email,
            'token' => Str::random(60),
            'created_at' => Carbon::now(),
            'expires_at' =>Carbon::now()
        ]);
        $tokenData = DB::table('password_resets')->where('email', $request->email)->first();
        // dd($tokenData);
        if ($this->sendResetEmail($request->email, $tokenData->token)) {
            return response()->json([
                'message' => "A reset link has been sent to your email address.",
                'alert' => 'Success',
            ]);     
        } 
        else {
            return response()->json([
                'message' => "A Network Error occurred. Please try again.",
                'alert' => 'error',
            ]); 
        }
    }

    private function sendResetEmail($email, $token)
    {
        //Retrieve the user from the database
        $user = DB::table('users')->where('email', $email)->select('name', 'email')->first();
        // dd(env('MAIL_FROM_NAME'));
        //Generate, the password reset link. The token generated is embedded in the link
        $SenderName=$user->name;
        $link = 'http://localhost:8000/api/'.'password/reset/' . $token;
        try {
            $sendEmail = new \SendGrid\Mail\Mail();
            $sendEmail->setFrom('samritpal430@gmail.com');
            $sendEmail->setSubject( "Reset Password Link" );
            $sendEmail->addTo( $email, $SenderName );
            $sendEmail->addContent( "text/plain", "Hello $SenderName ");
            $sendEmail->addContent(
            "text/html", "<strong>Click Here To Reset Your Password $link</strong>"
            );
            $apikey='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';
            $sendgrid = new \SendGrid($apikey);
            $response = $sendgrid->send( $sendEmail );
            // dd($response);
                return true;
        } 
        catch (\Exception $e) {
            return response()->json([
                'message' => "Link Not Generated.Please Try Again In Sometime",
                'alert' => 'error',
            ]);     
        }
    }

    public function resetPassLink ($token) 
    {
        $expiry_check=DB::table('password_resets')->where('token', $token)->first();
        if(!$expiry_check){
           return response()->json([
                'message' => "Link Expired. Please try again and Genrate New Link.",
                'token' => 'error',
            ]);  
        }
        $date_exp=$expiry_check->expires_at;
        $date_exp1=carbon::now();
        $to = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $date_exp);
        $from = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $date_exp1);
        $diff_in_minutes = $to->diffInMinutes($from);
        if ($diff_in_minutes<=15) {
            // return view('auth.reset', ['token' => $token]);
            return response()->json([
                'message' => 'reset password form',
                'token' => $token,
            ]);  
        }
        else{
            DB::table('password_resets')->where('token', $token)
            ->delete();
            return response()->json([
                'message' => "Link Expired. Please try again and Genrate New Link.",
                'token' => 'error',
            ]);  
        }
    }

    public function resetPassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
        'password' => 'required',
        'token' => 'required']);
        if ($validator->fails()) {
            return response()->json([
                'message' => "Complete The Form",
                'token' => 'error',
            ]);        
        }
        $password = $request->password;
        // Validate the token
        $tokenData = DB::table('password_resets')->where('token', $request->token)->first();
        // Redirect the user back to the password reset request form if the token is invalid
        if (!$tokenData) {
            return response()->json([
                'message' => "Token Invalid",
                'token' => 'error',
            ]); 
        }
        $user = User::where('email', $tokenData->email)->first();
        // Redirect the user back if the email is invalid
        if (!$user) {
            return response()->json([
                'message' => "Email not found.",
                'alert-type' => 'error',
            ]); 
        }
        //Hash and update the new password
        $user->password = Hash::make($password);
        $user->save();
        //Delete the token
        DB::table('password_resets')->where('email', $user->email)->delete();
        //Send Email Reset Success Email
        if ($this->sendSuccessEmail($user->email)) {
            return response()->json([
                'message' => "Password Reset Successfully (you can login now)",
                'alert-type' => 'success',
                ]);
        } 
        else {
            return response()->json([
                'message' => "A Network Error occurred. Please try again.",
                'alert-type' => 'error'
            ]);
        }
    }

    public function sendSuccessEmail($email)
        {
        $user = DB::table('users')->where('email', $email)->select('name')->first();
        try{
            $SenderName=$user->name;
            $sendEmail = new \SendGrid\Mail\Mail();
            // specify the email/name of where the email is coming from
            $sendEmail->setFrom('samritpal430@gmail.com', 'Amritpal Singh' );
            // set the email subject line
            $sendEmail->setSubject("Password Reset" );
            // specify the email/name we are sending the email to
            $sendEmail->addTo($email, $SenderName );
            // add our email body content
            $sendEmail->addContent( "text/plain", "Hello $SenderName");
            $sendEmail->addContent(
                "text/html", "<strong>Password Reset Successfully</strong>"
            );
            $apikey='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';
            $sendgrid = new \SendGrid($apikey);
            $response = $sendgrid->send( $sendEmail );
            return true;
        } 
        catch (\Exception $e) {
            // something went wrong so display the error message
            return response()->json([
                'message' => "something went wrong.",
                'alert-type' => 'error'
            ]);
        }
    }
}