<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\Client;
use DB;

class Connection
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        dd(\Config::get('mail.mailers.smtp.host'));
        $database = Client::select('*')->where('id', $request->id)->first();
        if(\Config::get('database.connections.pgsql2.database') !== DB::connection()->getDatabaseName())
        {
        \Config::set('database.connections.pgsql2.database', $database->db_name);
        \Config::set('database.connections.pgsql2.username', $database->db_username);
        \Config::set('database.connections.pgsql2.password', $database->db_password);
        }
        return $next($request);
    }
}
