<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\DatabaseController;
use App\Http\Controllers\ClientController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
#Main Db Api
Route::post('/register',[UserController::class,'register']);
Route::post('/login', [UserController::class,'login']);

Route::group(['middleware' => ['jwt.verify']], function() 
{
Route::post('logout', [UserController::class,'logout']);
Route::post('refresh', [UserController::class,'refresh']);
Route::get('profile', [UserController::class,'profile']);

#Client Api
Route::post('/create-client',[ClientController::class,'add']);
Route::get('/client',[ClientController::class,'get']);
Route::match(array('GET', 'POST'),'/client/{id}', [ClientController::class,'update']);
Route::post('/status/{id}',[ClientController::class,'status']);

#Database Connection
Route::get('connection/{id}',[DatabaseController::class,'connection'])->middleware('connection');

#Multi Database Api's(user)
Route::post('/user-register/{id}',[DatabaseController::class,'register'])->middleware('connection');
Route::match(array('GET','POST'),'connection/{id}/edit/{user_id}',[DatabaseController::class,'update'])->middleware('connection');
});

#Password Reset Api
    Route::post('/password/reset',[UserController::class,'validatePasswordRequest'])->middleware('guest');
    Route::get('/password/reset/{token}', [UserController::class,'resetPassLink'])->middleware('guest');
    Route::post('/reset_password_with_token', [UserController::class,'resetPassword']);

