<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clients', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('org');
            $table->string('email')->unique();
            $table->longText('password');
            $table->bigInteger('contact_no');
            $table->string('address');
            $table->integer('pincode');
            $table->string('state');
            $table->string('country');
            $table->string('host')->unique();
            $table->string('port');
            $table->string('db_name');
            $table->string('db_username');
            $table->longText('db_password');
            $table->enum('status',['active', 'inactive'])->default('active');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clients');
    }
}
